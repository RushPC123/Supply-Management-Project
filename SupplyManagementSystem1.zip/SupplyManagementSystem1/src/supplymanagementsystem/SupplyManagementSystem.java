/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package supplymanagementsystem;

import javax.swing.SwingUtilities;

/**
 * Main class for the Supply Management System
 * 
 * @author cheth
 */
public class SupplyManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Run the GUI on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ShipShape().setVisible(true);
            }
        });
    }
}
